 npm create vite@latest frontend
 npm install 
 npm run dev